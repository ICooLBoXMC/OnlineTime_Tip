<?php

namespace ICoolBoX\Task;

use pocketmine\Server;
use pocketmine\player\Player;

use pocketmine\plugin\PluginBase as Plugin;
use pocketmine\scheduler\Task;

use ICoolBoX\Main;

class OnlineTimeTask extends Task{
	
	public function __construct(Main $plugin){

        $this->plugin = $plugin;
    }

	public function onRun(): void{
      foreach(Server::getInstance()->getOnlinePlayers() as $player){
          $this->plugin->create($player);
          $this->plugin->addData($player);
          $this->plugin->onTime($player);
  	}
	}
}
