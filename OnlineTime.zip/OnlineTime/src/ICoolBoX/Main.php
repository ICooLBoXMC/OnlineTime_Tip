<?php

namespace ICoolBoX;

use pocketmine\Server;
use pocketmine\player\Player;

use pocketmine\plugin\PluginBase;

use pocketmine\event\Listener;

use pocketmine\event\player\{
    PlayerJoinEvent,
    PlayerQuitEvent
};

use ICoolBoX\Task\OnlineTimeTask;

class Main extends PluginBase implements Listener {
	

  public $data;
	
  public function onEnable(): void{
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    $this->getLogger()->info("=========================");
    $this->getLogger()->info("OnlineTime With Popup");
    $this->getLogger()->info("v0.1");
    $this->getLogger()->info("By ICoolBoX");
    $this->getLogger()->info("=========================");
    $this->getScheduler()->scheduleRepeatingTask(new OnlineTimeTask($this), 11);
    $this->saveResource("OnlineTime.yml");
    $this->data = yaml_parse(file_get_contents($this->getDataFolder() . "OnlineTime.yml"));
        
  }
  
  public function onQuit(PlayerQuitEvent $ev){
    file_put_contents($this->getDataFolder() . "OnlineTime.yml", yaml_emit($this->data));
  }
    
  public function onDisable(): void{
    file_put_contents($this->getDataFolder() . "OnlineTime.yml", yaml_emit($this->data));
  }

  public function create(Player $player){
     if(!isset($this->data["time"][strtolower($player->getName())])){
     $this->data["time"][strtolower($player->getName())] = 0;
     }
  }
    
  public function addData(Player $player){
     $this->data["time"][strtolower($player->getName())]++;
  }
    
  public function getData(Player $player){
     return $this->data["time"][strtolower($player->getName())];
  }
  
  public function onTime(Player $player){
  	$s = $this->getData($player);
      $h = floor ($s/3600); 
      $s -= $h*3600;
      $m = floor ($s/60); 
      $s -= $m*60;
	  $player->sendTip("§6PlayTime: §e".$h."§6h : §e".$m."§6m :.§e".$s."§6s ");
  }
	
}
